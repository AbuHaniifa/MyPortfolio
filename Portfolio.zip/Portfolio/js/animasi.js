// event pada saat link di klik
$('.page-scroll').on('click',function(e){

    // ambil isi href
    var tujuan = $(this).attr('href');
    // tangkap element ybs
    var elemenTujuan= $(Tujuan)

    // pindahkan Scroll
    $('body').animate([
        scrollTop=elemenTujuan.offset().top-50
    ],1250,'easeOutExpo');

    e.preventDefault();

});






// paralax
$(window).scroll(function(){
     var  wScroll = $(this).scrollTop();

     $ ('.jumbotron img').css({
         'transfrom' : 'translate(0px,'+ wScroll +'&)'
     })
     


})





